# planetarian 名片產生器 — 公司範本版
Copyright © 2026 吳國禎 (Kuo-Chen Wu). 設計保留權利；供 貴公司內部製名片使用。

## 一鍵批次產出
```
pip install cairosvg pypdf qrcode pillow    # 首次
python make_all.py            # 產出 people/ 內所有人的中英日名片
python make_all.py yuri       # 只產出某一人（對應 people/yuri.json）
```
輸出在 `out/<檔名>/`：三面 SVG＋PDF＋PNG 預覽，外加合併三面、含印刷 TrimBox 的 `<名>_名片.pdf`（91×55mm＋3mm 出血，直接送印）。

## 幫同事新增名片
1. 複製 `people/_template.json` 成 `people/<英文名>.json`
2. 填四類欄位（都支援三語）：
   - `name` 姓名、`latin_name`/`kana_name` 拉丁與假名署名、`suffix` 學位後綴、`title_en` 英文職稱副標
   - `field` 領域標語、`roles` 職務（每語最多 3 條）
   - `contact` 電話/信箱/網站，以及 **`qr`** 該員的 QR 目標網址（各自獨立）
3. `python make_all.py <英文名>`
> 假名務必用當事人護照/居留證的正式拼寫（片假名錯誤會失禮）。

## 設計是共用的
星空背景、光暈標題、夏季大三角、版面網格全部由 `card_engine.py` 提供，
所有人共用同一套視覺；JSON 只放個人內容。要調整全公司統一風格改引擎，
要改某人內容改該 JSON。
