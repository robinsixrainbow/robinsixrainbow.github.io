#!/usr/bin/env python3
"""批次名片產生器 — 讀 people/*.json，每人輸出中英日三面（SVG＋PDF＋合併預覽）。
用法：  python make_all.py            # 產出 people/ 內所有人
        python make_all.py yuri       # 只產出 people/yuri.json
輸出到 out/<檔名>/ ：zh/en/jp.pdf、合併三面 <名>_名片.pdf、預覽 png。"""
import json, os, sys, glob
import cairosvg
from card_engine import build_faces

sel = sys.argv[1:] if len(sys.argv) > 1 else None
files = ([f"people/{s}.json" for s in sel] if sel
         else [f for f in glob.glob("people/*.json") if not os.path.basename(f).startswith("_")])

for jf in files:
    who = os.path.splitext(os.path.basename(jf))[0]
    person = json.load(open(jf, encoding="utf-8"))
    faces = build_faces(person)
    outdir = f"out/{who}"
    os.makedirs(outdir, exist_ok=True)
    pdfs = []
    for lang, svg in faces.items():
        open(f"{outdir}/{lang}.svg", "w", encoding="utf-8").write(svg)
        cairosvg.svg2pdf(bytestring=svg.encode(), write_to=f"{outdir}/{lang}.pdf")
        cairosvg.svg2png(bytestring=svg.encode(), write_to=f"{outdir}/{lang}.png", output_width=1400)
        pdfs.append(f"{outdir}/{lang}.pdf")
    # 合併三面成一份、加 TrimBox（91×55mm＋3mm 出血）
    try:
        from pypdf import PdfWriter, PdfReader
        from pypdf.generic import RectangleObject
        MM = 72/25.4; w, h, b = 97*MM, 61*MM, 3*MM
        trim = RectangleObject((b, b, w-b, h-b)); bleed = RectangleObject((0, 0, w, h))
        wr = PdfWriter()
        for f in pdfs:
            pg = PdfReader(f).pages[0]; pg.trimbox = trim; pg.bleedbox = bleed; wr.add_page(pg)
        wr.add_metadata({"/Title": f"{person['name']['en']} — meishi", "/Author": person['name']['en']})
        with open(f"{outdir}/{who}_名片.pdf", "wb") as fp: wr.write(fp)
    except Exception as e:
        print(f"  (合併 PDF 略過：{e})")
    print(f"✓ {who}: 三面完成 → {outdir}/")

print(f"\n完成 {len(files)} 人。")
